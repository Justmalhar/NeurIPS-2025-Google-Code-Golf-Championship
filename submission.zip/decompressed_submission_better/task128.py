def p(r):
 s=[[*s]for s in zip(*r[::-1])]
 for B in range(len(s)):
  if s[B][0]:S=sum(s[B])//s[B][0];r=s[B][0];s[B]=[0]*15;s[B][S:S+S]=[r]*S
 return[[*s]for s in zip(*s)][::-1]