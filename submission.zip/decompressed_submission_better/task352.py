def p(r,c=enumerate):
 g=[[r for r,r in c(r)]for r in r]
 for n,r in c(r):
  for q,r in c(r):
   if r==2:
    for r in range(-1,2):
     for f in range(-1,2):
      try:
       if[r,f]!=[0,0]and n+r>-1and q+f>-1:g[n+r][q+f]=1
      except:0
 return g