def p(e,r=range,n=len):
 j=n(e);y=n(set(e[0]))-1;q=n({p[0]for p in e})-1
 for p in e:p[:]=(p[:y]*((n(p)-1)//y+1))[:n(p)]
 for h in r(j):e[h]=[e[h%q][p]for p in r(j)]
 return[[dict(zip(e[0],e[0][1:]))[p]for p in p]for p in e]