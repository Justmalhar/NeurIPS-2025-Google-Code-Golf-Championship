def p(j):
 for A in j:A[::3]=[6if v else v for v in A[::3]]
 return j