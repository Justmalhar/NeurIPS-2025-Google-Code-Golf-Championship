def p(g):
 for i in 0,3,6:
  a=g[i:i+3];A=tuple(map(tuple,a))
  if(A==tuple(x[::-1]for x in zip(*a[::-1])))+(A==tuple(zip(*a)))<1:return a