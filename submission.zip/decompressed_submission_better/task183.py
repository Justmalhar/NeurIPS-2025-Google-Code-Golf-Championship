def p(e):
 q=range;c=len(e);m=c//2-2;n=[];r=[e[0][0],e[0][-1],e[-1][0],e[-1][-1]]
 for p in q(2,c-2):
  j=[]
  for a in q(2,c-2):
   t=e[p][a]
   if t==8:o=(p-2)//m;t=(a-2)//m;t=r[o*2+t]
   j.append(t)
  n.append(j)
 return n