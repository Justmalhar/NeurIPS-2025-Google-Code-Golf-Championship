def p(g,f=range):
 if g[17][1]|g[17][17]:g.reverse()
 if g[1][17]:[A.reverse()for A in g]
 d=[[g[A][d]|g[~A][d]|g[A][~d]|g[~A][~d]for d in f(19)]for A in f(19)]
 for A in(1,3,5):
  if(r:=g[A][A+2]):
   for s in f(A+2,18-A,2):d[s][A]=d[s][~A]=d[A][s]=d[~A][s]=r
 return d