def p(g,r=range):
 a=[[0]*3for i in r(3)]
 for i in r(9):
  for j in r(9):
   if g[i][j]!=5:a[i//3][j//3]=g[i][j]
 return a