def p(p):
 d=range;e=[[[p[n+e*3][d+r*3]for d in d(3)]for n in d(3)]for e in d(len(p)//3)for r in d(len(p[0])//3)]
 for r in e:
  if[tuple(tuple(e[r][d]==0for d in d(3))for r in d(3))for e in e].count(tuple(tuple(r[e][d]==0for d in d(3))for e in d(3)))==1:return r