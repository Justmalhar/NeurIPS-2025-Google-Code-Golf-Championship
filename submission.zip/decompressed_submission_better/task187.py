def p(g):
 for i in g*4:g[0]=[i or 2for i in g[0]];g=[*zip(*eval(str(g).replace('0, 2','2, 2'))[::-1])]
 return[[[j,3-(j<1)][j in(0,2)]for j in i]for i in g]