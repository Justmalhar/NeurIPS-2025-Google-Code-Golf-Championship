def p(q,j=enumerate):
 f=len(q);k=[[0]*f for n in'm'*f];h={}
 for(o,p)in j(q):
  for(m,n)in j(p):
   if 0<n<3:h[n]=o,m;k[o][m]=n
 for(o,p)in j(q):
  for(m,n)in j(p):
   if n in(3,7):e,s=h[2-(n>3)];k[e+(o>e)-(o<e)][s+(m>s)-(m<s)]=n
 return k