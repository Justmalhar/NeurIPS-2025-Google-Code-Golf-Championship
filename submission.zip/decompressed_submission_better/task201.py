def p(e):
 d=enumerate;o=next;q=lambda u,t:u<1or e[u-1][t]<1or u>2and e[u-1][t]==4and e[u-2][t]>0;(k,t),(m,a),(f,m),m=[divmod(d,13)for(d,k)in d(sum(e,[]))if k==4];i=o(k for d in zip(*e)if 4not in d for k in d if k);n=o(k for(k,t)in d(e)if any(t==i and q(k,d)for(d,t)in d(t)));s=o(k for(k,t)in d(zip(*e))if any(t==i and q(d,k)for(d,t)in d(t)))
 for d in range(f-k-1):
  for o in range(a-t-1):e[k+d+1][[a-o-1,t+o+1][e[k+1][t]==i]],e[n+d][s+o]=e[n+d][s+o],0
 return[d[t:a+1]for d in e[k:f+1]]