def p(g,r=range(6)):
 for i in r:
  if g[i][0]|g[i][-1]:g[i]=[2]*6;a=i
  if g[0][i]|g[-1][i]:
   for R in g:R[i]=8;b=i
 g[a][b]=4;return g