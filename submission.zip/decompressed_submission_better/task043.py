def p(d,r=range,l=len):
 for B in r(1,l(d)):
  if d[B][-1]==5:
   for e in r(l(d)-1):
    if d[0][e]==5:d[B][e]=2
 return d