def p(o):
	A=len(o);C=[[0]*A for B in' '*A];B=-1;D=0;E=[1,1j,-1,-1j]
	for F in[A]+[A for A in range(A-1,0,-2)for B in'  ']:
		for G in range(F):B+=E[D%4];C[int(B.imag)][int(B.real)]=3
		D+=1
	return C