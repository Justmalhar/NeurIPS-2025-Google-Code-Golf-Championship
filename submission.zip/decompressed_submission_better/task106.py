z=lambda g:[*map(list,zip(*g[::-1]))]
p=lambda g:((g:=[a+b for a,b in zip(g,z(g))]),g+z(z(g)))[1]