def p(d):
 def f(y,x):
  if w>x>-1<y<len(d)and d[y][x]:d[y][x]=0;[f(y-1+i//3,x-1+i%3)for i in range(9)]
 f(*divmod(sum(d,[]).index(2),w:=len(d[0])));return[[8*(2not in sum(d,[]))]]