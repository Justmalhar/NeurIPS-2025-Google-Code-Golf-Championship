def p(p):
 n=range
 d=[[0]*3for r in n(3)]
 for r in n(3):
  for a in n(3):
   t=0
   for c in n(3):
    for l in n(3):
     if p[r*4+c][a*4+l]==6:t+=1
   d[r][a]=1if t>=2else 0
 return d
