def p(a):
 u,n=len(a),len(a[0]);f,u,r,d=u,n,-1,-1
 for t in range(u):
  for o in range(n):
   if a[t][o]!=0:
    if t<f:f=t
    if t>r:r=t
    if o<u:u=o
    if o>d:d=o
 if r<0:return[[]]
 a=[tuple(a[t][u:d+1])for t in range(f,r+1)];s=[];n=None
 for o in a:
  if o!=n:s.append(o);n=o
 p=list(zip(*s))if s else[];s=[];n=None
 for o in p:
  if o!=n:s.append(o);n=o
 return[list(t)for t in zip(*s)]
