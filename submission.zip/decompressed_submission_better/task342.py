def p(e,f=enumerate):
 def a():
  a=[0]*10
  for(o,n)in f(e):
   for(i,n)in f(n):
    if n!=8and n:a[i]=n;e[o][i]=0
    if n==8:a=[a for a in a if a];e[o][i],e[o][i+1]=a[0],a[1];return
 for i in(0,1):a();e=e[::-1]
 return e