def p(g,e=enumerate):
 for(o,i)in e(g):
  for(s,d)in e(i):
   if d<1and(r:=g[o-1][s])and r==i[s-1]:return[[r]]