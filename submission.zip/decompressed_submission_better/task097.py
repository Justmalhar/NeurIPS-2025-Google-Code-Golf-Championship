i=len
t=range
def p(e):
 r,s=i(e),i(e[0]);f=[f for t in e for f in t];f=sorted(f)[-1];e=[[0]+t+[0]for t in e];d=[[0]*(s+2)];e=d+e+d;d=[[1,1],[-1,-1],[-1,1],[1,-1],[0,1],[0,-1],[-1,0],[1,0],[0,0]]
 for r in t(1,r+1):
  for g in t(1,s+1):
   if e[r][g]==f:
    u=[e[t[0]+r][t[1]+g]for t in d]
    if sum(u)==f:e[r][g]=0
 e=e[1:-1];e=[t[1:-1]for t in e];return e