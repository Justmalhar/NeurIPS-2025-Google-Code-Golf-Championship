def p(g):
 for i in range(1,9):
  for j in range(1,9):
   if g[i+1][j]*g[i][j+1]*g[i-1][j]*g[i][j-1]:g[i][j]=2
 return g