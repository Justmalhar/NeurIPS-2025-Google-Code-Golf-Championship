def p(g):
 for i,x in enumerate(g[2]):
  if x:g[2][i],g[-1][i]=0,1
 return g