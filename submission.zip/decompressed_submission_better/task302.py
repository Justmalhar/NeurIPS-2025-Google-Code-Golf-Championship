def p(j):
	F,D=len(j),len(j[0]);C=[[0]*D for A in j];E=[]
	def I(W,l):
		E=[(W,l)];C[W][l]=1;G=[(W,l)];H=1
		while E:
			I,J=E.pop()
			for(K,L)in[(0,1),(1,0),(0,-1),(-1,0)]:
				A,B=I+K,J+L
				if not(0<=A<F and 0<=B<D):H=0;continue
				if j[A][B]<1 and not C[A][B]:C[A][B]=1;E+=[(A,B)];G+=[(A,B)]
		return G if H else[]
	for A in range(F):
		for B in range(D-1,-1,-1):
			if j[A][B]<1 and not C[A][B]:E+=[I(A,B)]
	for(A,G)in enumerate(E):
		J=min(8,max(6,len(G)**.5+.0+5))
		for H in G:j[H[0]][H[1]]=J
	return j