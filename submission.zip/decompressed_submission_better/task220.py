def p(l,p=enumerate):
	C={8:4,2:1,3:6}
	for(D,E)in p(l):
		for(F,G)in p(E):
			for A in range(-1,2):
				for B in range(-1,2):
					try:
						if[A,B]!=[0,0]:l[D+A][F+B]=C[G]
					except:0
	return l