R=range
def p(g):
	B=sum(g,[]);A=B.count(0);G=9-A;C=[[0]*(A*3)for B in R(A*3)]
	for D in R(G):
		for E in R(3):
			for F in R(3):
				if g[E][F]:C[E+D//A*3][F+D%A*3]=max(B)
	return C