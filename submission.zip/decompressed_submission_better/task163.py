def p(l):
 j=range
 for o in j(3):
  for e in j(3):
   n=[[l[4*o+t][4*e+j]for j in j(3)]for t in j(3)]
   for e in j(3):
    for d in j(3):
     if n[e][d]==4:
      t=[[0]*11for j in j(11)]
      for r in j(3):
       for g in j(3):t[4*e+r][4*d+g]=n[r][g]
      for n in j(11):t[n][3]=t[n][7]=t[3][n]=t[7][n]=5
      return t