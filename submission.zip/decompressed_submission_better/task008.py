def p(g):
	C=enumerate
	for D in[0]*4:A=max(A for(A,B)in C(g)if 2 in B);B=min(A for(A,B)in C(g)if 8 in B);g=[*zip(*(B>A)*(B-A-1)*[[0]*len(g[0])]+(g[:A+1]+g[B:],g)[A>=B])][::-1]
	return g