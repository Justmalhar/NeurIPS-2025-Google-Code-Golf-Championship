def p(p):
	A=range;B=[A[:]for A in p];G=[[p[B][A]for A in A(3)]for B in A(3)]
	for C in A(9):
		for D in A(4,13):
			if p[C][D]==1:
				for E in A(-1,2):
					for F in A(-1,2):B[C+E][D+F]=G[E+1][F+1]
	return B