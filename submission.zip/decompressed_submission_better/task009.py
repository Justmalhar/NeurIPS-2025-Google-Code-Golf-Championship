def p(m):
 b=range((f:=len(m)));c=m[2][2];r=eval(str((o:=[[r*(r!=c)for r in r]for r in m])));u=lambda g:(g.index(d),f-g[::-1].index(d))
 for d in b:
  for l in b:
   if d in(g:=o[l]):a,e=u(g);r[l][a:e]=[d]*(e-a)
   if d in(g:=[r[l]for r in o]):
    for g in range(*u(g)):r[g][l]=d
 return[[(c,r[l][g])[m[l][g]!=c]for g in b]for l in b]