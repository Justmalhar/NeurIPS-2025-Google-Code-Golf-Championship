def p(g):
 for k in range(100):
  if g[i:=k//10][j:=k%10]:
   s=[(i,j)];t=s[:];g[i][j]=0
   while s:
    x,y=s.pop()
    for a,b in(1,0),(0,1),(-1,0),(0,-1):
     if 10>(X:=x+a)>=0<=(Y:=y+b)<10 and g[X][Y]:g[X][Y]=0;s+=[(X,Y)];t+=s[-1:]
   for x,y in t:g[x][y]=5-len(t)
 return g
