def p(d):
 for(s,e)in enumerate(d[-1]):
  if e:
   for o in d:o[s:10:2]=[e]*len(o[s:10:2])
   e=d[0];e[s+1:10:4]=[5]*len(e[s+1:10:4]);e=d[-1];e[s+3:10:4]=[5]*len(e[s+3:10:4]);break
 return d