f=len
n=range
def p(g):
 e=[[0,0,0]for p in n(3)];d,d=f(g),f(g[0])
 for p in n(d):
  for r in n(d):
   if g[p][r]==5:
    for o in n(-1,2):
     for a in n(-1,2):
      if p+o>=0and r+a>=0and g[p+o][r+a]!=0:e[1+o][1+a]=g[p+o][r+a]
 return e