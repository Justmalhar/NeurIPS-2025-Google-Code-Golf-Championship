def p(g):
 a=[0]*10;R=range(10)
 for i in R:
  for j in R:
   r=g[i];v=r[j]
   if v:a[v]=r.count(v)*sum(t[j]==v for t in g)
 return[[a.index(max(a))]*2]*2